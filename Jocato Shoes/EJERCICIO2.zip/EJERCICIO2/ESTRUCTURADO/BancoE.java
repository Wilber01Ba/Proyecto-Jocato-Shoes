package EJERCICIO2.ESTRUCTURADO;

import java.util.Scanner;

public class BancoE {
    public static void main(String[] args) {
        Scanner consola = new Scanner(System.in);

        System.out.println("*** Bienvenido al banco de Josué y Wilber ***");
        System.out.println("Por favor ingrese el número de cuentas que va a ingresar");
        int numCuentas = Integer.parseInt(consola.nextLine());

        long[] numerosCuentas = new long[numCuentas];
        String[] fechasCreacion = new String[numCuentas];
        int[] tiposCuenta = new int[numCuentas];
        double[] saldosCuentas = new double[numCuentas];
        double[] interesesMensuales = new double[numCuentas];
        double[] saldosConInteres = new double[numCuentas];

        double valorTotalIntereses = 0;
        double valorTotalSaldos = 0;

        System.out.println("*** Bienvenido al sistema de ingreso de datos ***");
        for (int i = 0; i < numCuentas; i++){
            System.out.println("Va ingresar la información de la cuenta número \"" + (i + 1) + "\"");

            System.out.println("Por favor ingrese el número de cuenta");
            numerosCuentas[i] = Long.parseLong(consola.nextLine());

            System.out.println("Por favor digite la fecha de creación de su cuenta en formato aaaa/mm/dd");
            fechasCreacion[i] = consola.nextLine();

            System.out.println("Por favor ingrese el saldo de la cuenta");
            saldosCuentas[i] = Double.parseDouble(consola.nextLine());

            System.out.println("Digite el tipo de cuenta, 1: AhorroDiario, 2: CuentaJoven, 3: Tradicional");
            tiposCuenta[i] = Integer.parseInt(consola.nextLine());

            try {
                interesesMensuales[i] = switch (tiposCuenta[i]){
                    case 1 -> saldosCuentas[i] * 0.015;
                    case 2 -> saldosCuentas[i] * 0.017;
                    case 3 ->saldosCuentas[i] * 0.016;
                    default -> throw new RuntimeException("Tipo de cuenta no disponible, abortando el proceso .....");
                };
            }catch (Exception e){
                System.out.println("Digitó un tipo de cuenta no soportado");
            }

            saldosConInteres[i] = saldosCuentas[i] + interesesMensuales[i];

            valorTotalIntereses += interesesMensuales[i];
            valorTotalSaldos += saldosCuentas[i];
        }

        System.out.println("\n--- Resultados ---");
        for (int i = 0; i < numCuentas; i++){
            System.out.println("Cuenta " + numerosCuentas[i]);
            System.out.printf("Interes mensual: $%.2f\n", interesesMensuales[i]);
            System.out.printf("Saldo con interes: $%.2f\n", saldosConInteres[i]);
            System.out.println("------------------------");
        }
        System.out.printf("Total intereses: $%.2f\n", valorTotalIntereses);
        System.out.printf("Total saldos con interes: $%.2f", valorTotalSaldos);



    }

}
