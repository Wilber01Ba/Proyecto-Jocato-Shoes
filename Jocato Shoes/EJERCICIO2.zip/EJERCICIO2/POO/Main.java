package EJERCICIO2.POO;

public class Main {
    public static void main(String[] args) {
        System.out.println("===== PRUEBA CLASE CUENTA =====");

        Cuenta cuenta1 = new Cuenta(
                1001234567L,
                "Carlos Pérez",
                "carlos@example.com",
                312456789,
                "Calle 12 #4-56",
                987654321L,
                "2023/05/10",
                2,
                5000000.0
        );

        System.out.println("Cliente: " + cuenta1.getNombre());
        System.out.println("Tipo de cuenta: " + cuenta1.getTipoCuenta());
        System.out.println("Saldo actual: " + cuenta1.getSaldo());
        System.out.println("Interés mensual calculado: " + cuenta1.calcularInteres());
        System.out.println();


        System.out.println("===== PRUEBA CLASE CUENTA CORRIENTE =====");

        CuentaCorriente corriente1 = new CuentaCorriente(
                2003456789L,
                "María Gómez",
                "maria@example.com",
                315987654,
                "Carrera 8 #45-23",
                1122334455L,
                "2024/01/15",
                3500000.0,
                1.8,
                1000000.0
        );

        System.out.println("Cliente: " + corriente1.getNombre());
        System.out.println("Saldo actual: " + corriente1.getSaldo());
        System.out.println("Porcentaje interés: " + corriente1.getPorcentajeInteres() + "%");
        System.out.println("Sobregiro permitido: " + corriente1.getValorSobregiro());
        System.out.println("Interés mensual calculado: " + corriente1.calcularInteres());
        System.out.println();


        System.out.println("===== POLIMORFISMO =====");

        Cliente[] clientes = {cuenta1, corriente1};

        for (Cliente c : clientes) {
            if (c instanceof Cuenta cuenta) {
                System.out.println("Cuenta ahorro (" + cuenta.getNombre() + ") → Interés: " + cuenta.calcularInteres());
            } else if (c instanceof CuentaCorriente corriente) {
                System.out.println("Cuenta corriente (" + corriente.getNombre() + ") → Interés: " + corriente.calcularInteres());
            }
        }
    }
}
