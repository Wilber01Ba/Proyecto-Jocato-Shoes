package EJERCICIO2.POO;

public class Cuenta extends Cliente{
    private long numeroCuenta;
    private String fechaApertura;
    private int tipoCuenta;
    private double saldo;

    public Cuenta(long documentoIdentidad, String nombre, String correoElectronico, int numeroCelular, String direccion, long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
        super(documentoIdentidad, nombre, correoElectronico, numeroCelular, direccion);
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
    }

    public Cuenta(long numeroCuenta, String fechaApertura, int tipoCuenta, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.fechaApertura = fechaApertura;
        this.tipoCuenta = tipoCuenta;
        this.saldo = saldo;
    }

    public double calcularInteres(){
        return switch (this.tipoCuenta){
            case 1 -> this.saldo * 0.015;
            case 2 -> this.saldo * 0.017;
            case 3 -> this.saldo * 0.016;
            default -> 0;
        };
    }

    public long getNumeroCuenta() {
        return this.numeroCuenta;
    }

    public void setNumeroCuenta(long numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getFechaApertura() {
        return this.fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public int getTipoCuenta() {
        return this.tipoCuenta;
    }

    public void setTipoCuenta(int tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
