package com.crud.crud.dao.controller;

import com.crud.crud.dao.model.Estudiante;
import com.crud.crud.dao.response.EstudianteMetadataResponse;
import com.crud.crud.dao.service.EstudianteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/est")
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService;

    @GetMapping
    public ResponseEntity<EstudianteMetadataResponse> traerTodos() {
        return this.estudianteService.traerEst();
    }

    @PostMapping
    public ResponseEntity<EstudianteMetadataResponse> guardarEst(@RequestBody Estudiante estudiante) {
        return this.estudianteService.guardarEst(estudiante);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstudianteMetadataResponse> actualizaEst(@PathVariable long id, @RequestBody Estudiante estudiante) {
        return this.estudianteService.actualizarEst(estudiante,id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<EstudianteMetadataResponse> eliminarEst(@PathVariable long id) {
        return this.estudianteService.eliminarEst(id);
    }
}
