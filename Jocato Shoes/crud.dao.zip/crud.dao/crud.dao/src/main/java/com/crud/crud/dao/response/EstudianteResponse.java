package com.crud.crud.dao.response;

import com.crud.crud.dao.model.Estudiante;

import java.util.ArrayList;
import java.util.List;

public class EstudianteResponse {
    List<Estudiante> estudiantes = new ArrayList<>();

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(List<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }
}
