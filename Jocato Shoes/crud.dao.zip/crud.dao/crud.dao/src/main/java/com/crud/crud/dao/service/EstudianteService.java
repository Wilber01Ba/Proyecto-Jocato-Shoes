package com.crud.crud.dao.service;

import com.crud.crud.dao.model.Estudiante;
import com.crud.crud.dao.response.EstudianteMetadataResponse;
import org.springframework.http.ResponseEntity;

public interface EstudianteService {
    ResponseEntity<EstudianteMetadataResponse> traerEst();
    ResponseEntity<EstudianteMetadataResponse> guardarEst(Estudiante estudiante);
    ResponseEntity<EstudianteMetadataResponse> actualizarEst(Estudiante estudiante, long id);
    ResponseEntity<EstudianteMetadataResponse> eliminarEst(long id);


}
