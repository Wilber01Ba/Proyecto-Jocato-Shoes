package com.crud.crud.dao.response;

public class EstudianteMetadataResponse extends MetadataResponse{
    private EstudianteResponse estudianteResponse = new EstudianteResponse();

    public EstudianteResponse getEstudianteResponse() {
        return estudianteResponse;
    }

    public void setEstudianteResponse(EstudianteResponse estudianteResponse) {
        this.estudianteResponse = estudianteResponse;
    }
}
