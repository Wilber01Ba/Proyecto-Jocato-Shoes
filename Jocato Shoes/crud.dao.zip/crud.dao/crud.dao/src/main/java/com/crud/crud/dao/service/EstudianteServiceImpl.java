package com.crud.crud.dao.service;

import com.crud.crud.dao.model.Estudiante;
import com.crud.crud.dao.response.EstudianteMetadataResponse;
import com.crud.crud.dao.response.MetadataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

@Service
public class EstudianteServiceImpl implements EstudianteService {
    private static final List<Estudiante> estudianteList = new ArrayList<>(
            List.of(
                    new Estudiante(1, "Ana", 20),
                    new Estudiante(2, "Carlos", 22),
                    new Estudiante(3, "María", 19)
            )
    );


    private static final Logger logger = LoggerFactory.getLogger(EstudianteServiceImpl.class);


    @Override
    public ResponseEntity<EstudianteMetadataResponse> traerEst() {
        logger.info("Entrando al método de listar todos los estudiantes");
        EstudianteMetadataResponse response = new EstudianteMetadataResponse();

        logger.info("Devolviendo respuesta al cliente");
        response.getEstudianteResponse().setEstudiantes(estudianteList);
        response.setMetadata("OK", "200");
        return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<EstudianteMetadataResponse> guardarEst(Estudiante estudiante) {
        logger.info("Entrando al método de guardar estudiantes");
        EstudianteMetadataResponse response = new EstudianteMetadataResponse();
        Predicate<Estudiante> validarExistencia = estudiante1 -> estudianteList.contains(estudiante1);
        List<Estudiante> estudianteList1 = new ArrayList<>();


        if (validarExistencia.test(estudiante)) {
            logger.error("Estudiante ya existente");
            response.setMetadata("nOK", "500");
            return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.BAD_REQUEST);
        }

        estudianteList.add(estudiante);
        estudianteList1.add(estudiante);

        logger.info("Devolviendo respuesta al cliente");
        response.getEstudianteResponse().setEstudiantes(estudianteList1);
        response.setMetadata("OK", "200");
        return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.OK);

    }

    @Override
    public ResponseEntity<EstudianteMetadataResponse> actualizarEst(Estudiante estudiante, long id) {
        logger.info("Entrando al método de actualizar estudiante");
        EstudianteMetadataResponse response = new EstudianteMetadataResponse();

        try {
            List<Estudiante> estudianteList1 = new ArrayList<>();
            logger.info("Intentanto recuperar estudiante con id {} ", id);
            Estudiante estudiantew = estudianteList.stream().filter(est -> id == est.getId()).findFirst().
                    orElseThrow(() -> new RuntimeException("Estudiante con id " + id + " no encontrado"));

            estudiantew.setEdad(estudiante.getEdad());
            estudiantew.setNombre(estudiante.getNombre());

            estudianteList1.add(estudiantew);
            response.getEstudianteResponse().setEstudiantes(estudianteList1);
        } catch (RuntimeException e) {
            logger.error("Error al actualizar estudiante con id {}  no fue encontrado", id);
            e.printStackTrace();
            response.setMetadata("nOK", "500");
            return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.BAD_REQUEST);
        }

        logger.info("Devolviendo respuesta al cliente");
        response.setMetadata("OK", "200");
        return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<EstudianteMetadataResponse> eliminarEst(long id) {
        logger.info("Entrando al método de eliminar estudiante");
        EstudianteMetadataResponse response = new EstudianteMetadataResponse();

        try {
            logger.info("Intentanto recuperar estudiante con id {} ", id);

            Optional<Estudiante> estudiantew = estudianteList.stream().filter(x -> x.getId() == id).findFirst();
            estudiantew.orElseThrow(() -> new RuntimeException("Estudiante con id " + id + " no fue encontradop"));

            estudianteList.remove(estudiantew.get());
        } catch (RuntimeException e) {
            logger.error("Estudiante con id {} no encontrado", id);
            e.printStackTrace();
            response.setMetadata("nOK", "500");
            return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.BAD_REQUEST);
        }

        response.setMetadata("OK", "200");

        return new ResponseEntity<EstudianteMetadataResponse>(response, HttpStatus.OK);

    }
}
