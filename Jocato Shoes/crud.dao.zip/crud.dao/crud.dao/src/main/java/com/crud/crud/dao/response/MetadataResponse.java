package com.crud.crud.dao.response;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MetadataResponse {
    List<HashMap<String,String>> metadata = new ArrayList<>();

    public List<HashMap<String, String>> getMetadata() {
        return metadata;
    }

    public void setMetadata(String estado, String codigo) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaActual = dateTimeFormatter.format(LocalDate.now());

        HashMap<String,String> meta = new HashMap<>();

        meta.put("Codigo",codigo);
        meta.put("Estado", estado);
        meta.put("Fecha", fechaActual);

        this.metadata.add(meta);
    }
}
